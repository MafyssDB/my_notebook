<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('expenses', function (Blueprint $table) {
            $table->id();
            $table->decimal('amount');
            $table->text('description')->nullable();
            $table->foreignId('category_id')->index()->references('id')->on('expense_categories')->onDelete('cascade');
            $table->foreignId('user_id')->index()->references('id')->on('users')->onDelete('cascade');
            $table->date('date_operation');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('expenses');
    }
};
