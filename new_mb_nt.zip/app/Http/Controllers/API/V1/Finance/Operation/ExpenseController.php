<?php

namespace App\Http\Controllers\API\V1\Finance\Operation;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ExpenseController extends OperationController
{

}
