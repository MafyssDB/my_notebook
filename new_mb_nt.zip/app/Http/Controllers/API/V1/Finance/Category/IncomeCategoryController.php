<?php

namespace App\Http\Controllers\API\V1\Finance\Category;


class IncomeCategoryController extends CategoryController
{

}
