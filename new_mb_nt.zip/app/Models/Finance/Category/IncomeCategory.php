<?php

namespace App\Models\Finance\Category;


class IncomeCategory extends Category
{
    protected $table = 'income_categories';
}
