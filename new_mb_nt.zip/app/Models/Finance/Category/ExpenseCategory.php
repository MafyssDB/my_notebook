<?php

namespace App\Models\Finance\Category;

class ExpenseCategory extends Category
{
    protected $table = 'expense_categories';
}
