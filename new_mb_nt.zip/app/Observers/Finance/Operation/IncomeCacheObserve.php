<?php

namespace App\Observers\Finance\Operation;

use App\Observers\BaseCacheObserve;

class IncomeCacheObserve extends BaseCacheObserve
{

}
