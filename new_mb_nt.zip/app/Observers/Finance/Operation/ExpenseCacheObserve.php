<?php

namespace App\Observers\Finance\Operation;

use App\Observers\BaseCacheObserve;

class ExpenseCacheObserve extends BaseCacheObserve
{

}
