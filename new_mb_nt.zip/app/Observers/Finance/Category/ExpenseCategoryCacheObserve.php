<?php

namespace App\Observers\Finance\Category;

use App\Observers\BaseCacheObserve;

class ExpenseCategoryCacheObserve extends BaseCacheObserve
{

}
